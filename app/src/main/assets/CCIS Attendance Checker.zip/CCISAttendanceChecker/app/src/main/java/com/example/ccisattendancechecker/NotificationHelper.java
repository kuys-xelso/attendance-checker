package com.example.ccisattendancechecker;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.net.Uri;
import android.os.Build;

import androidx.core.app.NotificationCompat;

public class NotificationHelper {    private static final String CHANNEL_ID = "ongoing_event_channel";
    private static final String CHANNEL_NAME = "Ongoing Event Notifications";

    // Create Notification Channel (For Android 8.0 and higher)
    public static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channel.setDescription("Notifications for ongoing events");
            NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    // Show the notification
    public static void showNotification(Context context, String eventName) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        Uri soundUri = Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.notif_sound);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.icon_notification)  // Use your app's icon
                .setContentTitle("Ongoing Event: " + eventName)
                .setContentText("An event is currently ongoing. Don't miss it!")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setSound(soundUri)
                .setVibrate(new long[]{0, 1000, 500, 1000, 1000});

        if (notificationManager != null) {
            notificationManager.notify(1, builder.build()); // 1 is the notification ID
        }
    }
}