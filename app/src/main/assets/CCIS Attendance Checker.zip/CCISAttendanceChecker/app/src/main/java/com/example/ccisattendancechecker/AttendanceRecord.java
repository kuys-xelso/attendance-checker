package com.example.ccisattendancechecker;

import com.google.firebase.Timestamp;

public class AttendanceRecord {

    private String eventName;
    private String cutOffTime;
    private Timestamp dateCreated;
    private String createdBy;
    private String qrCode;

    // Default constructor required for Firestore
    public AttendanceRecord() {}

    public AttendanceRecord(String eventName, String createdBy, String cutoffTime) {
        this.eventName = eventName;
        this.dateCreated = Timestamp.now();
        this.createdBy = createdBy;
        this.cutOffTime = cutoffTime;
        this.qrCode = generateQRCode();
    }

    private String generateQRCode() {

        return eventName + "_" +createdBy + "_" + dateCreated.getSeconds();

    }


    // Getters and setters
    public String getEventName() { return eventName; }
    public void setEventName(String eventName) { this.eventName = eventName; }


    public String getCreatedBy() { return createdBy; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }

    public String getCutOffTime() {
        return cutOffTime;
    }

    public void setCutOffTime(String cutOffTime) {
        this.cutOffTime = cutOffTime;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public Timestamp getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Timestamp dateCreated) {
        this.dateCreated = dateCreated;
    }

}