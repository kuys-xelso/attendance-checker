package com.example.ccisattendancechecker;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = auth.getCurrentUser();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {


                if (currentUser != null) {
                    // If the user is logged in, navigate to the home screen

                    db.collection("users")
                            .whereEqualTo("email", currentUser.getEmail())
                            .get()
                            .addOnSuccessListener(documentSnapshots -> {
                                if (!documentSnapshots.isEmpty()){
                                    DocumentSnapshot documentSnapshot = documentSnapshots.getDocuments().get(0);
                                    String name = documentSnapshot.getString("name");
                                    String userRole = documentSnapshot.getString("user_role");
                                    String yearLevel = documentSnapshot.getString("year_level");
                                    String section = documentSnapshot.getString("section");
                                    String emailUser = documentSnapshot.getString("email");

                                   Intent intent = new Intent(SplashActivity.this, MainActivity.class); // Change this to your main activity
                                    intent.putExtra("name", name);
                                    intent.putExtra("userRole", userRole);
                                    intent.putExtra("yearLevel", yearLevel);
                                    intent.putExtra("section", section);
                                    intent.putExtra("email", emailUser);
                                    startActivity(intent);
                                    finish();

                                }
                            });


                         } else {
                    // If the user is not logged in, navigate to the login screen
                   Intent intent = new Intent(SplashActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }


            }
        }, 1000);

    }
}