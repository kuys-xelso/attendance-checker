package com.example.ccisattendancechecker;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_profile);

        ImageView backButton = findViewById(R.id.editProfileBackButton);
        ImageView imageViewProfile = findViewById(R.id.imageViewProfile);


        //get the image uri
        String imageUriString = getIntent().getStringExtra("imageUri");
        if(imageUriString != null ){
            Uri imageUri = Uri.parse(imageUriString);
            imageViewProfile.setImageURI(imageUri);
        }

        backButton.setOnClickListener(v -> {
            finish();
        });


    }
}