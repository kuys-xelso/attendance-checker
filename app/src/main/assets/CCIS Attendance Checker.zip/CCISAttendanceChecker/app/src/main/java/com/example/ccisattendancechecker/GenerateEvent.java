package com.example.ccisattendancechecker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


public class GenerateEvent extends AppCompatActivity {

    private EditText eventNameEditText;
    private TimePicker timePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_generate_qr);

        //initialization
        eventNameEditText = findViewById(R.id.eventNameEditText);
        timePicker = findViewById(R.id.timePicker);
        ImageButton imageButtonBack = findViewById(R.id.backButton);

        imageButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //initialize generate qr button
        Button generateQrButton = findViewById(R.id.generateQrButton);

        generateQrButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                generateEvent();
            }
        });

    }


    private void generateEvent() {
        String eventName = eventNameEditText.getText().toString().trim();

        // Check if event name is empty
        if (eventName.isEmpty()) {
            Toast.makeText(GenerateEvent.this, "Please enter event name", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get time from TimePicker
        int hour = timePicker.getHour();
        int minute = timePicker.getMinute();

        // Set up Calendar and format cut-off time
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);

//        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
//        String cutOffTimeString = timeFormat.format(calendar.getTime());
        Date cutOffTime = calendar.getTime();

//         Generate a unique QR code string
        String qrCode = String.format(
                "Event: %s, Cut-off: %s, UUID: %s",
                eventName,
                new SimpleDateFormat("hh:mm a", Locale.getDefault()).format(cutOffTime),
                java.util.UUID.randomUUID().toString()
        );

        // Format the creation date as a string
        String dateCreatedString = new SimpleDateFormat("MMM dd, yyyy hh:mm a", Locale.getDefault())
                .format(new Date());

        // Get the email of the current user (fallback to "Unknown" if not authenticated)
        FirebaseAuth auth = FirebaseAuth.getInstance();
        String createdBy = auth.getCurrentUser() != null ? auth.getCurrentUser().getEmail() : "Unknown";

        // Prepare attendance data for Firestore
        Map<String, Object> attendanceData = new HashMap<>();
        attendanceData.put("eventName", eventName);
        attendanceData.put("cutOffTime", cutOffTime);
        attendanceData.put("dateCreated", dateCreatedString); // Store date as string
        attendanceData.put("createdBy", createdBy);

        // Save attendance data to Firestore
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("attendance")
                .add(attendanceData)
                .addOnSuccessListener(documentReference -> {
                    // Success message
                    Toast.makeText(GenerateEvent.this, "QR code generated successfully", Toast.LENGTH_SHORT).show();

//                     Navigate to QR Code view
//                    Intent intent = new Intent(GenerateEvent.this, QrCodeView.class);
//                    intent.putExtra("eventName", eventName);
//                    intent.putExtra("time", cutOffTime.getSeconds() * 1000L);
//                    intent.putExtra("qrCode", qrCode);
//                    intent.putExtra("dateCreated", dateCreatedString);
//                    startActivity(intent);

//                     Finish current activity
                    finish();
                })
                .addOnFailureListener(e -> {
                    // Display error message
                    Toast.makeText(GenerateEvent.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });

    }
}
