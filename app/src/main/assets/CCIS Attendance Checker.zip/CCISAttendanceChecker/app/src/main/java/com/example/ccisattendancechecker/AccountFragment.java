package com.example.ccisattendancechecker;

import static android.app.Activity.RESULT_OK;
import static android.content.Intent.getIntent;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

public class AccountFragment extends Fragment {


    private TextView usernameTextview;
    private TextView userRoleTextView;
    private static final int PICK_IMAGE_REQUEST = 1;
    private ActivityResultLauncher<Intent> imagePickerLauncher;

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Register the ActivityResultLauncher
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        if (data != null && data.getData() != null) {
                            Uri imageUri = data.getData();
                            // Start SecondActivity with the selected image
                            Intent intent = new Intent(requireActivity(), EditProfileActivity.class);
                            intent.putExtra("imageUri", imageUri.toString());
                            startActivity(intent);
                        } else {
                            showError("No image data received");
                        }
                    } else if (result.getResultCode() == Activity.RESULT_CANCELED) {
                        Toast.makeText(requireContext(),
                                "Image selection cancelled",
                                Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_account, container, false);

        Button logout = view.findViewById(R.id.logoutButton);
        Button editProfile = view.findViewById(R.id.editProfile);
        usernameTextview = view.findViewById(R.id.nameTextview);
        userRoleTextView = view.findViewById(R.id.roleTextview);


        Bundle bundle = getArguments();
        if (bundle != null) {
            String name = bundle.getString("name");
            String role = bundle.getString("userRole");
            String yearLevel = bundle.getString("yearLevel");
            String section = bundle.getString("section");
            String email = bundle.getString("email");

            usernameTextview.setText(name);
            userRoleTextView.setText(role);

        }

        RelativeLayout changepassMenu = view.findViewById(R.id.changePassLayout);
        RelativeLayout notificationMenu =  view.findViewById(R.id.notificatonLayout);
        RelativeLayout  deleteAccountMenu =  view.findViewById(R.id. deleteAccountLayout);




        //edit profile
        editProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openGallery();

            }
        });


        //going to change pass activity
        changepassMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), ChangePasswordActivity.class);
                startActivity(intent);

            }
        });

        //deleting the account
        deleteAccountMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(view.getContext())
                        .setTitle("Confirm Deletion")
                        .setMessage("Are you sure you want to delete this account?")
                        .setIcon(R.drawable.icon_exclamation)
                        .setPositiveButton("Yes", (dialogInterface, i) -> {

                            Toast.makeText(getActivity(), "Account deleted", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getActivity(),LoginActivity.class));
                            requireActivity().finish();

                        })
                        .setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.dismiss())
                        .show();
            }
        });

        //logout button
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(view.getContext())
                        .setTitle("Confirm Logout")
                        .setMessage("Are you sure you want to Logout?")
                        .setPositiveButton("Yes", (dialogInterface, i) -> {

                            FirebaseAuth.getInstance().signOut();
                            Toast.makeText(getActivity(), "Logout Successful", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getActivity(),LoginActivity.class));
                            requireActivity().finish();

                        })
                        .setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.dismiss())
                        .show();
            }
        });

       return view;
    }

    private void openGallery() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("image/*");

            // Add these flags to get persistable URI permission
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

            imagePickerLauncher.launch(intent);
        } catch (ActivityNotFoundException e) {
            showError("No gallery app found");
        } catch (Exception e) {
            showError("Error opening gallery: " + e.getMessage());
        }
    }

    private void showError(String message) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_LONG).show();
        Log.e("ImagePicker", message);
    }

}