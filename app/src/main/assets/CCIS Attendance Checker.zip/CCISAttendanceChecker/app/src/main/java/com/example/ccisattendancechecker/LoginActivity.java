package com.example.ccisattendancechecker;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class LoginActivity extends AppCompatActivity {

    private FirebaseAuth auth;

    private EditText emailEditText;
    private EditText passwordEditText;
    private boolean isPasswordVisible = false;
    FirebaseFirestore db = FirebaseFirestore.getInstance();


    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        //initialization
        auth = FirebaseAuth.getInstance();
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        Button button_login = findViewById(R.id.button_login);


        // Navigate to the signup activity
        TextView registerLink = findViewById(R.id.registerLink);
        registerLink.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, CreateAccountActivity.class));
        });


        passwordEditText.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                // Check if the touch is within the drawable area (right side of the EditText)
                Drawable drawableEnd = passwordEditText.getCompoundDrawables()[2];
                if (drawableEnd != null) {
                    int drawableWidth = drawableEnd.getBounds().width();
                    if (event.getRawX() >= (passwordEditText.getRight() - drawableWidth - passwordEditText.getPaddingEnd())) {
                        togglePasswordVisibility();
                        return true;
                    }
                }
            }
            return false;
        });

        // Set a focus change listener to automatically hide the password when it loses focus
        passwordEditText.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                hidePassword(); // Automatically hide the password on focus loss
            }
        });

        // Handle the login button click
        button_login.setOnClickListener(v -> login());
    }

    private void login() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (email.isEmpty()) {
            Toast.makeText(this, "Email is required", Toast.LENGTH_SHORT).show();
            emailEditText.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Password is required", Toast.LENGTH_SHORT).show();
            passwordEditText.requestFocus();
            return;
        }

        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        //check if the user is verified
                        FirebaseUser user = auth.getCurrentUser();
                        if (user != null) {
                            String userEmail = user.getEmail();
                            db.collection("users")
                                    .whereEqualTo("email", userEmail)
                                    .get()
                                    .addOnSuccessListener(documentSnapshots -> {
                                        if (!documentSnapshots.isEmpty()) {
                                            DocumentSnapshot documentSnapshot = documentSnapshots.getDocuments().get(0);
                                            String fname = documentSnapshot.getString("firstname");
                                            String lname = documentSnapshot.getString("lastname");
                                            String middleInitial = documentSnapshot.getString("middle_initial");
                                            String userRole = documentSnapshot.getString("user_role");
                                            String yearLevel = documentSnapshot.getString("year_level");
                                            String section = documentSnapshot.getString("section");
                                            String emailUser = documentSnapshot.getString("email");
                                            String course = documentSnapshot.getString("course");

                                            // Pass the data to the MainActivity
                                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                            intent.putExtra("fname", fname);
                                            intent.putExtra("lname", lname);
                                            intent.putExtra("middleInitial", middleInitial);
                                            intent.putExtra("userRole", userRole);
                                            intent.putExtra("yearLevel", yearLevel);
                                            intent.putExtra("section", section);
                                            intent.putExtra("email", emailUser);
                                            intent.putExtra("course", course);

                                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                            startActivity(intent);
                                            finish();

                                            Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                                        } else {
                                            Toast.makeText(LoginActivity.this, "User data not found", Toast.LENGTH_SHORT).show();
                                        }


                                    })
                                    .addOnFailureListener(e -> {
                                        Log.e("LoginActivity", "Error fetching user data", e);
                                        Toast.makeText(LoginActivity.this, "Failed to fetch user data", Toast.LENGTH_SHORT).show();
                                    });
                        }
                    } else {
                        // Handle login failure
                        Exception exception = task.getException();
                        if (exception != null) {
                            Log.e("LoginActivity", "Login failed", exception);
                            Toast.makeText(LoginActivity.this, "Login failed: " + exception.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });

       }



//    private void fetchUserData() {
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//        if (currentUser != null) {
//            // For debugging
//
//            Log.d("UserProfile", "Current User ID: " + currentUser.getEmail());
//
//            db.collection("users")
//                    .whereEqualTo("email", currentUser.getEmail())
//                    .get()
//                    .addOnCompleteListener(task -> {
//                        if (task.isSuccessful() && !task.getResult().isEmpty()) {
//                            DocumentSnapshot document = task.getResult().getDocuments().get(0);
//                            if (document.exists()) {
//                                String userName = document.getString("name");
//                                String userRole = document.getString("user_role");
//
//
//                                if (userName != null) {
//                                    usernameTextview.setText(userName);
//                                    userRoleTextView.setText(userRole);
//                                } else {
//                                    Log.d("UserProfile", "Name field is null");
//                                }
//                            } else {
//                                Log.d("UserProfile", "No such document");
//                                Toast.makeText(requireContext(), "User data not found",
//                                        Toast.LENGTH_SHORT).show();
//                            }
//                        } else {
//                            Log.d("UserProfile", "Error getting data", task.getException());
//                            if (isAdded()) {
//                                Toast.makeText(requireContext(), "Error fetching user data",
//                                        Toast.LENGTH_SHORT).show();
//                            }
//                        }
//                    });
//        } else {
//            Log.d("UserProfile", "No user is signed in");
//        }
//    }



    private void togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible;
        updatePasswordVisibility();
    }

    private void hidePassword() {
        if (isPasswordVisible) {
            isPasswordVisible = false;
            updatePasswordVisibility();
        }
    }

    private void updatePasswordVisibility() {
        Drawable startDrawable = passwordEditText.getCompoundDrawables()[0]; // Retain left drawable
        @SuppressLint("UseCompatLoadingForDrawables") Drawable endDrawable = isPasswordVisible
                ? getResources().getDrawable(R.drawable.icon_visibility_on)
                : getResources().getDrawable(R.drawable.icon_visibility_off);

        passwordEditText.setInputType(isPasswordVisible
                ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        passwordEditText.setCompoundDrawablesWithIntrinsicBounds(startDrawable, null, endDrawable, null);

        // Move the cursor to the end of the text
        passwordEditText.setSelection(passwordEditText.getText().length());
    }
}