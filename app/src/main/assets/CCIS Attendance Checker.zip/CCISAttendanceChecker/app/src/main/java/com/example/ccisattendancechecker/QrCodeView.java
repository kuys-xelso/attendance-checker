package com.example.ccisattendancechecker;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class QrCodeView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_qr_code_view);

        //initialization
        ImageButton imageButtonBack = findViewById(R.id.backButton);
        ImageView qrImageView = findViewById(R.id.qrImageView);
        TextView eventNameTextView = findViewById(R.id.eventNameTextView);
        TextView timeTextView = findViewById(R.id.cutOffTimeTextView);


        imageButtonBack.setOnClickListener(v -> {
            finish();
        });

        //passed data from generate qr
        String qrCodeString = getIntent().getStringExtra("qrCode");
        String eventName = getIntent().getStringExtra("eventName");
        long cutOffTimeMillis = getIntent().getLongExtra("cutOffTime", -1);

        eventNameTextView.setText(eventName != null ? eventName : "Event name not available");

        // Format and display cut-off time
        if (cutOffTimeMillis != -1) {
            Date cutOffTime = new Date(cutOffTimeMillis);
            SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
            timeTextView.setText("Cut off Time: " +timeFormat.format(cutOffTime));
        } else {
            timeTextView.setText("");
        } 


        //generate qr code
        Bitmap qrCode = generateQrCode(qrCodeString);
        qrImageView.setImageBitmap(qrCode);

    }

    private Bitmap generateQrCode(String qrCodeString) {
        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
        try{
            BitMatrix bitMatrix = multiFormatWriter.encode(qrCodeString, BarcodeFormat.QR_CODE,900,900);

            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            return barcodeEncoder.createBitmap(bitMatrix);

        }catch (WriterException e){
            throw new RuntimeException(e);
        }

    }
}