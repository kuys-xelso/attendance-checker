package com.example.ccisattendancechecker;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;


public class HomeFragment extends Fragment {

 TabLayout tabLayout;
 ViewPager viewPager;
 private VPAdapter vpAdapter;
 private TextView usernameTextview;
 private TextView userRoleTextView;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        usernameTextview = view.findViewById(R.id.nameTextview);
        userRoleTextView = view.findViewById(R.id.roleTextview);
        viewPager = view.findViewById(R.id.viewpager);
        tabLayout = view.findViewById(R.id.tablayout);

        tabLayout.setupWithViewPager(viewPager);

         vpAdapter = new VPAdapter(getChildFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);

         setupViewPager(vpAdapter);

         viewPager.setAdapter(vpAdapter);
         tabLayout.setupWithViewPager(viewPager);

        Bundle bundle = getArguments();
        if (bundle != null) {
            String fname = bundle.getString("fname");
            String lname = bundle.getString("lname");
            String middleInitial = bundle.getString("middleInitial");
            String role = bundle.getString("userRole");
            String yearLevel = bundle.getString("yearLevel");
            String section = bundle.getString("section");
            String course = bundle.getString("course");
            String email = bundle.getString("email");

            // Use the data as needed
         usernameTextview.setText(fname + " "+ middleInitial + ". " + lname);
         userRoleTextView.setText(role + "   "+ course + "  " + yearLevel + " - " + section);

        }

        return view;
    }

//I dont need this function anymore
//    public void onViewCreated(View view, Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//
//        mAuth = FirebaseAuth.getInstance();
//        db = FirebaseFirestore.getInstance();
//
//        fetchUserData();
//    }
//
//    private void fetchUserData() {
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//        if (currentUser != null) {
//            // For debugging
//
//            Log.d("UserProfile", "Current User ID: " + currentUser.getEmail());
//
//            db.collection("users")
//                    .whereEqualTo("email", currentUser.getEmail())
//                    .get()
//                    .addOnCompleteListener(task -> {
//                        if (task.isSuccessful() && !task.getResult().isEmpty()) {
//                            DocumentSnapshot document = task.getResult().getDocuments().get(0);
//                            if (document.exists()) {
//                                String userName = document.getString("name");
//                                String userRole = document.getString("user_role");
//
//
//                                if (userName != null) {
//                                    usernameTextview.setText(userName);
//                                    userRoleTextView.setText(userRole);
//                                } else {
//                                    Log.d("UserProfile", "Name field is null");
//                                }
//                            } else {
//                                Log.d("UserProfile", "No such document");
//                                Toast.makeText(requireContext(), "User data not found",
//                                        Toast.LENGTH_SHORT).show();
//                            }
//                        } else {
//                            Log.d("UserProfile", "Error getting data", task.getException());
//                            if (isAdded()) {
//                                Toast.makeText(requireContext(), "Error fetching user data",
//                                        Toast.LENGTH_SHORT).show();
//                            }
//                        }
//                    });
//        } else {
//            Log.d("UserProfile", "No user is signed in");
//        }
//    }

    private void setupViewPager(VPAdapter vpdapter) {
        vpdapter.addFragment(new EventFragment(), "Events");
        vpdapter.addFragment(new RecordsFragment(), "Records");
    }
}




