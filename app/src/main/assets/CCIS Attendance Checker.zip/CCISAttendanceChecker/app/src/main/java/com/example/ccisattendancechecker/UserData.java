package com.example.ccisattendancechecker;

public class UserData {
    private String studentId;
    private String name;
    private String email;
    private String section;

    public String getUserRole() {
        return userRole;
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
    }

    public String getYearLevel() {
        return yearLevel;
    }

    public void setYearLevel(String yearLevel) {
        this.yearLevel = yearLevel;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    private String course;
    private String yearLevel;
    private String userRole;

    // Required empty constructor for Firestore
    public UserData() {}

    // Constructor
    public UserData(String studentId, String name, String email, String section,
                String course, String yearLevel, String userRole) {
        this.studentId = studentId;
        this.name = name;
        this.email = email;
        this.section = section;
        this.course = course;
        this.yearLevel = yearLevel;
        this.userRole = userRole;
    }

}
