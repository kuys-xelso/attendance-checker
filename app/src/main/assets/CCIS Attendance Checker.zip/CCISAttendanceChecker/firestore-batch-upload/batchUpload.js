const admin = require('firebase-admin');

// Initialize Firebase Admin SDK
admin.initializeApp({
  credential: admin.credential.cert(require('./service-account.json')),
});

const db = admin.firestore();

async function batchUploadStudents() {
  // Array of student data to be uploaded
  const students = [
                     {
                       course: 'IT',
                       firstname: 'Lucas',
                       lastname: 'Anderson',
                       middle_initial: 'M',
                       section: 'B',
                       student_id: '123466',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Sophia',
                       lastname: 'Garcia',
                       middle_initial: 'L',
                       section: 'B',
                       student_id: '123467',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Liam',
                       lastname: 'Martinez',
                       middle_initial: 'J',
                       section: 'B',
                       student_id: '123468',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Emma',
                       lastname: 'Lopez',
                       middle_initial: 'K',
                       section: 'B',
                       student_id: '123469',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Noah',
                       lastname: 'Santos',
                       middle_initial: 'R',
                       section: 'B',
                       student_id: '123470',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Olivia',
                       lastname: 'Reyes',
                       middle_initial: 'C',
                       section: 'B',
                       student_id: '123471',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Elijah',
                       lastname: 'Gonzales',
                       middle_initial: 'S',
                       section: 'B',
                       student_id: '123472',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Ava',
                       lastname: 'Rivera',
                       middle_initial: 'T',
                       section: 'B',
                       student_id: '123473',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'William',
                       lastname: 'Cruz',
                       middle_initial: 'H',
                       section: 'B',
                       student_id: '123474',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Isabella',
                       lastname: 'Torres',
                       middle_initial: 'P',
                       section: 'B',
                       student_id: '123475',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'James',
                       lastname: 'Ramos',
                       middle_initial: 'N',
                       section: 'B',
                       student_id: '123476',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Mia',
                       lastname: 'Gutierrez',
                       middle_initial: 'V',
                       section: 'B',
                       student_id: '123477',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Benjamin',
                       lastname: 'Flores',
                       middle_initial: 'W',
                       section: 'B',
                       student_id: '123478',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Charlotte',
                       lastname: 'Bautista',
                       middle_initial: 'Q',
                       section: 'B',
                       student_id: '123479',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Henry',
                       lastname: 'Castro',
                       middle_initial: 'F',
                       section: 'B',
                       student_id: '123480',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Amelia',
                       lastname: 'Morales',
                       middle_initial: 'G',
                       section: 'B',
                       student_id: '123481',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Alexander',
                       lastname: 'Espinoza',
                       middle_initial: 'D',
                       section: 'B',
                       student_id: '123482',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Harper',
                       lastname: 'Salvador',
                       middle_initial: 'O',
                       section: 'B',
                       student_id: '123483',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Ethan',
                       lastname: 'Jimenez',
                       middle_initial: 'E',
                       section: 'B',
                       student_id: '123484',
                       user_role: 'Student',
                       year_level: '3'
                     },
                     {
                       course: 'IT',
                       firstname: 'Evelyn',
                       lastname: 'Mendoza',
                       middle_initial: 'U',
                       section: 'B',
                       student_id: '123485',
                       user_role: 'Student',
                       year_level: '3'
                     }
                   ];


  const collectionRef = db.collection('users'); // Name of your Firestore collection
  const batch = db.batch();

  students.forEach((student) => {
    const docRef = collectionRef.doc(); // Automatically generate a document ID
    batch.set(docRef, student);
  });

  try {
    await batch.commit();
    console.log('Batch upload successful!');
  } catch (error) {
    console.error('Error during batch upload:', error);
  }
}

// Run the function
batchUploadStudents();